
import React from "react";
import { Card, CardContent } from "../components/ui/card";
import { Button } from "../components/ui/button";

export default function Home() {
  const seasons = ["Winter", "Spring", "Summer", "Autumn"];
  const styles = ["Modern", "Boho", "Scandinavian", "Minimalist"];

  return (
    <main className="min-h-screen bg-[#fdf7f6] text-[#5a4b41] p-6">
      <header className="text-center py-10">
        <h1 className="text-4xl font-bold text-[#caa7a3]">CozyNest</h1>
        <p className="mt-2 text-lg text-[#8f8f8f]">
          Your hub for seasonal interior inspiration & shoppable looks.
        </p>
      </header>

      <section className="mb-12">
        <h2 className="text-2xl font-semibold text-[#8ba89c] mb-4">Browse by Season</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {seasons.map((season) => (
            <Card key={season} className="bg-[#f5f0ed] hover:shadow-xl transition">
              <CardContent className="p-4 text-center">
                <h3 className="text-xl font-medium text-[#5a4b41]">{season}</h3>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section className="mb-12">
        <h2 className="text-2xl font-semibold text-[#8ba89c] mb-4">Browse by Style</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {styles.map((style) => (
            <Card key={style} className="bg-[#f5f0ed] hover:shadow-xl transition">
              <CardContent className="p-4 text-center">
                <h3 className="text-xl font-medium text-[#5a4b41]">{style}</h3>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section>
        <h2 className="text-2xl font-semibold text-[#8ba89c] mb-4">Featured Room</h2>
        <Card className="bg-[#f5f0ed]">
          <CardContent className="p-4">
            <div className="flex flex-col md:flex-row gap-4">
              <img
                src="/featured-room.jpg"
                alt="Featured Room"
                className="w-full md:w-1/2 rounded-xl"
              />
              <div>
                <h3 className="text-xl font-bold text-[#5a4b41] mb-2">
                  Cozy Spring Bedroom
                </h3>
                <ul className="mb-4 text-[#5a4b41]">
                  <li>
                    • Sage Green Duvet Cover - <a className="underline" href="#">IKEA</a>
                  </li>
                  <li>
                    • Beige Throw Pillows - <a className="underline" href="#">NEXT</a>
                  </li>
                  <li>
                    • Rattan Side Table - <a className="underline" href="#">H&M Home</a>
                  </li>
                </ul>
                <Button className="bg-[#caa7a3] text-white hover:bg-[#b48d8a]">
                  View More Details
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </section>
    </main>
  );
}
